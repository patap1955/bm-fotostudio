<?php

namespace App\Http\Controllers;

use App\Mail\ContactsForm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class PageController extends Controller
{
    public function index() {
        //return view('pages.main.index');
        return view('master');
    }

    public function formContacts(Request $request)
    {
        $mail = new \stdClass();
        $mail->name = $request->name;
        $mail->phone = $request->phone;
//        return response()->json($mail);
        if (Mail::to('mia.sydykova@gmail.com')->send(new ContactsForm($mail))) {
//            Contact::create($request->all());
//            return back();
            return response()->json($request);
        } else {
            return response()->json(["answer" => "error"]);
        }
    }
}
