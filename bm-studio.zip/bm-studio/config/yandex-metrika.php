<?php

/**
 * Настройки Yandex Metrika
 */
return [
    //https://oauth.yandex.ru/authorize?response_type=token&client_id=0d5753cf394a4311b3cabc8b915cbdd6
    'cache'         => 60,      //Время жизни кэша в минутах , с версии laravel 5.8 в секундах
    'counter_id'    => '72990874',      //Id счетчика Яндекс метрики
    'token'         => 'y0_AgAAAAAH56eTAAiK8QAAAADSv_E_QsTsLSK1R66TQrLmEvkjPW8s6x4',      //oauth token
];
